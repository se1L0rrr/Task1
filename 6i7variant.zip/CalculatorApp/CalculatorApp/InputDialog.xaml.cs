﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CalculatorApp
{
    /// <summary>
    /// Логика взаимодействия для InputDialog.xaml
    /// </summary>
    public partial class InputDialog : Window
    {
        public double Number1 { get; private set; }
        public double Number2 { get; private set; }
        public InputDialog()
        {
            InitializeComponent();
        }
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
          

            if (double.TryParse(txtNumber1.Text, out double num1) &&
                 double.TryParse(txtNumber2.Text, out double num2))
            {
                Number1 = num1;
                Number2 = num2;

                string resultMessage = "";

                if (chkSumma.IsChecked == true)
                {
                    resultMessage += $"Сумма: {Number1 + Number2}\n";
                }

                if (chkMaxDivisor.IsChecked == true)
                {
                    resultMessage += $"Наибольший общий делитель: {NOD(Number1, Number2)}\n";
                }

                if (chkMultiply.IsChecked == true)
                {
                    resultMessage += $"Произведение: {Number1 * Number2}\n";
                }

                MessageBox.Show(resultMessage, "Результаты вычислений");
                
               
            }
            else
            {
                
                MessageBox.Show("Пожалуйста, введите действительные числа.", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        
        private int NOD(double a, double b)
        {
            while (b != 0)
            {
                double temp = b;
                b = a % b;
                a = temp;
            }
            return (int)a;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
        private void Quit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}