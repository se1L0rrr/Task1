﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp6
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        Dictionary<string, List<Address>> addresses = new Dictionary<string, List<Address>>();
    
        public MainWindow()
        {
            InitializeComponent();
            AddAddress("Ленинградская", 45);
            AddAddress("К.Маркса", 1);
            AddAddress("Советская", 44);
            AddAddress("Ленина", 234);
            AddAddress("Суворова", 240);
            AddAddress("Энгельса", 109);
            AddAddress("Ворошилова", 32/1);
            AddAddress("50-лет Магнитки", 22);
            AddAddress("Труда", 104);
            AddAddress("Б.Ручьева", 14);
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchInput = KeyTextBox.Text;

            
            string[] parts = searchInput.Split(',');

            if (parts.Length == 2)
            {
                string street = parts[0].Trim();
                int number;

                if (int.TryParse(parts[1], out number))
                {
                    foreach (var addressPair in addresses)
                    {
                        foreach (var address in addressPair.Value)
                        {
                            if (address.Street == street && address.Number == number)
                            {
                                ValueTextBlock.Text = $"Адрес найден\nУлица: {address.Street}, Номер дома: {address.Number}";
                                return;
                            }
                        }
                    }
                }
            }

            ValueTextBlock.Text = "Адрес не найден, либо неккоректно введен";
        }

        private void AddAddress(string street, int number)
        {
            if (addresses.ContainsKey(street))
            {
                addresses[street].Add(new Address(street, number));
            }
            else
            {
                addresses.Add(street, new List<Address> { new Address(street, number) });
            }
        }
        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {

            string streetName = KeyTextBox.Text;
            string[] parts = streetName.Split(',');

            if (parts.Length == 2)
            {
                string street = parts[0].Trim();
                int number;
                if (int.TryParse(parts[1], out number))
                {
                    foreach (var addressPair in addresses)
                    {
                        var addressList = addressPair.Value;
                        for (int i = 0; i < addressList.Count; i++)
                        {
                            if (addressList[i].Street == street && addressList[i].Number == number)
                            {
                                addressList.RemoveAt(i);
                                ValueTextBlock.Text = "Адрес успешно удален";
                                return;
                            }
                        }
                    }
                }
            }

            ValueTextBlock.Text = "Адрес не найден, либо неккоректно введен";
        }


        private void ShowAllButton_Click(object sender, RoutedEventArgs e)
        {
            ValueTextBlock.Text = "";

            foreach (var addressPair in addresses)
            {
                foreach (var address in addressPair.Value)
                {
                    ValueTextBlock.Text += $"Улица: {address.Street}, Номер дома: {address.Number}\n";
                }
            }
        }

        private void ClearAllButton_Click(object sender, RoutedEventArgs e)
        {
            addresses.Clear();
            ValueTextBlock.Text = "Все элементы удалены";
        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            string addInput = KeyTextBox.Text;

            string[] parts = addInput.Split(',');

            if (parts.Length == 2)
            {
                string street = parts[0].Trim();
                int number;

                if (int.TryParse(parts[1], out number))
                {
                    if (addresses.ContainsKey(street))
                    {
                        addresses[street].Add(new Address(street, number));
                    }
                    else
                    {
                        addresses.Add(street, new List<Address> { new Address(street, number) });
                    }

                    ValueTextBlock.Text = "Адрес успешно добавлен";
                    return;
                }
            }

            ValueTextBlock.Text = "Некорректный ввод адреса";
        }
    }
    public class Address
    {
        public string Street { get; set; }
        public int Number { get; set; }

        public Address(string street, int number)
        {
            Street = street;
            Number = number;
        }
    }
}

