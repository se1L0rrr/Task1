﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp39
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void ChooseImageButton_Click(object sender, RoutedEventArgs e)
        {
           
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif",
                Title = "Выберите изображение"
            };

          
            if (openFileDialog.ShowDialog() == true)
            {
               
                var bitmap = new BitmapImage(new Uri(openFileDialog.FileName));
                ImagePreview.Source = bitmap; 
            }
        }

       

        private void DeleteImageButton_Click(object sender, RoutedEventArgs e)
        {
            ImagePreview.Source = null;
        }
        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            
            TitleTextBox.Clear();
            DatePicker.SelectedDate = null;
            LocationTextBox.Clear();
            DescriptionTextBox.Clear();
            ImagePreview.Source = null;
            StartTime.Clear();
            EndTime.Clear();
           
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
           
            string title = TitleTextBox.Text;
            DateTime? date = DatePicker.SelectedDate;
            string location = LocationTextBox.Text;
            string description = DescriptionTextBox.Text;
            string starttime = StartTime.Text;
            string endtime = EndTime.Text;





            string filePath = "meetup.txt";

            using (StreamWriter writer = new StreamWriter(filePath, true)) 
            {
                writer.WriteLine("Название: " + title);
                writer.WriteLine("Дата: " + date?.ToString("d")); 
                writer.WriteLine("Место: " + location);
                writer.WriteLine("Описание: " + description);
                writer.WriteLine("Время начала: " + starttime);
                writer.WriteLine("Время начала: " + endtime);
                writer.WriteLine("-----------------------------------");
            }

            MessageBox.Show("Данные успешно сохранены!");
        }

        private void AddProgramButton_Click(object sender, RoutedEventArgs e)
        {

        }
        
        private void RemoveProgramButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}

