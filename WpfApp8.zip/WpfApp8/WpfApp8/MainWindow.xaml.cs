﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp8
{
    /// <summary> 
    /// Логика взаимодействия для MainWindow.xaml 
    /// </summary> 
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            img1.Source = new BitmapImage(new Uri("https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Kheops-Pyramid.jpg/274px-Kheops-Pyramid.jpg"));
            img2.Source = new BitmapImage(new Uri("https://rus.team/images/article/42335/2018-11-09-351_73460-1_479685.webp"));
            img3.Source = new BitmapImage(new Uri("https://cs9.pikabu.ru/post_img/big/2017/05/19/4/14951698791491511.jpg"));
            img4.Source = new BitmapImage(new Uri("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMqCSt59V-euiG2V3f8BXZRHlX0TOyJwlDxQ&s"));
            img5.Source = new BitmapImage(new Uri("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXJ3CyL-JCGygBH_bqy_hQ1YJdWYqAx4HvLA&s"));
            img6.Source = new BitmapImage(new Uri("https://putidorogi-nn.ru/images/stories/7_chudes_sveta/koloss-rodosskiy_3.jpg"));

            text1.Text = "пирамида Хеопса";
            text2.Text = "Висячие сады Семирамиды";
            text3.Text = "Статуя Зевса в Олимпии";
            text4.Text = "Храм Артемиды в Эфесе";
            text5.Text = "Мавзолей в Галикарнасе";
            text6.Text = "Колосс Родосский";



        }

        public void Button_Click0(object sender, RoutedEventArgs e)
        {
            ImageRotation.Angle += 90;
        }
        public void Button_Click_0(object sender, RoutedEventArgs e)
        {
            ImageRotation.Angle -= 90;
        }

        public void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ImageRotation1.Angle -= 90;
        }

        public void Button_Click1(object sender, RoutedEventArgs e)
        {
            ImageRotation1.Angle += 90;
        }
        public void Button_Click_2(object sender, RoutedEventArgs e)
        {
            ImageRotation2.Angle -= 90;
        }
        public void Button_Click2(object sender, RoutedEventArgs e)
        {
            ImageRotation2.Angle += 90;
        }
        public void Button_Click_3(object sender, RoutedEventArgs e)
        {
            ImageRotation3.Angle -= 90;
        }
        public void Button_Click3(object sender, RoutedEventArgs e)
        {
            ImageRotation3.Angle += 90;
        }
        public void Button_Click_4(object sender, RoutedEventArgs e)
        {
            ImageRotation4.Angle -= 90;
        }
        public void Button_Click4(object sender, RoutedEventArgs e)
        {
            ImageRotation4.Angle += 90;
        }
        public void Button_Click_5(object sender, RoutedEventArgs e)
        {
            ImageRotation5.Angle -= 90;
        }
        public void Button_Click5(object sender, RoutedEventArgs e)
        {
            ImageRotation5.Angle += 90;
        }
    }
}